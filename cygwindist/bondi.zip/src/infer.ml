open List
open Format
open Datum
open P_data
open Console
open Environments

type precision = Exact | LessThan 


(*** instantiating and closing types *) 
(* both processes freshen bound type variables *) 

let rec inst_tyscheme_with_bvars  = function
   | Quant(x,ty) -> 
      let bv = nextTypeVar() in 
      let sub = TyMap.add x (TyV(bv,0)) idSub in 
      let (ty1,bvs1) = inst_tyscheme_with_bvars ty in 
      (applySub sub ty1,bv :: bvs1)
  | ty -> (ty,[]) 

let inst_tyscheme ty = fst (inst_tyscheme_with_bvars ty) 


let clos_ty sub sEnv ty = 
  let bTyVars = 
    fold_right list_remove (freeTyVarsInSEnv sub sEnv) (freeTyVars sub ty) in 
  let (sub1,tyvs1) = freshen_tyvars bTyVars in 
  let sub2 = composeSubs sub1 sub 
  in 
  fold_right (fun x y -> Quant(x,y)) tyvs1 (applySub sub2 ty)

 

(*** unification and matching *)


let addSubCheck sub tyv ty = 
  let tyvs = freeTyVars sub ty in 
  if  List.mem tyv tyvs
  then typeError [TyV (tyv,0); ty] "produce an occurence error in unification"
  else composeSubs (TyMap.add tyv ty TyMap.empty) sub 
;;

let avoid x sub = 
  let aux _ ty b = b && not (mem x (freeTyVars idSub ty)) 
  in 
  TyMap.fold aux sub true
;;


let rec unify_p fixed constraints precision sub ty0 ty1 = 
  (* fixed = fixed tyvars. that cannot be replaced, 
     but other variables may be mapped to them. 
     unlike quantified variables that must be completely avoided. 
  *) 

  if get_mode "types" = Show_off
  then sub 
  else 
    let ty2 = applySub sub ty0
    and ty3 = applySub sub ty1 
    in
    match (ty2,ty3) with
      (* the subunify part *) 
    | _,TyC(TyVar "Top",_) when precision = LessThan -> sub
    | TyV (x,_), ApplyF(g1,f1) when not (mem x fixed) && not (mem x (freeTyVars idSub f1)) -> 
	let ty = TyV(nextTypeVar(),0) in 
	let sub1 = addSubCheck sub x (ApplyF(g1,ty)) in 
	unify_p fixed constraints precision sub1 ty f1 
    | TyV (x,_), Funty(g1,f1) when not (mem x fixed) && not (mem x (freeTyVars idSub f1)) -> 
	let ty = TyV(nextTypeVar(),0) in 
	let sub1 = addSubCheck sub x (Funty(g1,ty)) in 
	unify_p fixed constraints precision sub1 ty f1 
    | ApplyF(g0,f0), ApplyF(g1,f1)
    | Funty(g0,f0), Funty(g1,f1) -> unify_p fixed constraints precision (unify_p fixed constraints Exact sub g0 g1) f0 f1
    |_, TyV (x,_) when precision = LessThan && mem (ty2,x) constraints -> sub 

    (* the unify part *)

    | TyV _, TyV _ 
    | TyC _, TyC _ when ty2 = ty3 -> sub 
    | (_,TyV (x,_)) when not (mem x fixed) -> addSubCheck sub x ty2
    | (TyV (x,_),_) when not (mem x fixed) -> addSubCheck sub x ty3
    | (Linty f1,Linty f2)
    | (Ref f1, Ref f2) 
    | (Array f1, Array f2) -> unify_p fixed constraints Exact sub f1 f2 
    | (Quant(x1,f1), Quant(x2,f2)) ->
	let (sub1,x) = freshen_tyvar2 x1 x2 in 
	let sub2 = unify_p(x::fixed) constraints precision sub (applySub sub1 f1) (applySub sub1 f2) in 
	if avoid x sub2 
	then sub2
	else typeError [ ty2; ty3] "don't unify"
    | _ -> typeError [ ty2; ty3] "don't unify"
;;


      
let rec unify fixed sub ty0 ty1 = unify_p fixed [] Exact sub ty0 ty1 
 
let rec subunify fixed constraints sub ty0 ty1 = 
unify_p fixed constraints LessThan sub ty0 ty1 

(* delete ??

  (* fixed = fixed tyvars. that cannot be replaced, 
     but other variables may be mapped to them. 
     unlike quantified variables that must be completely avoided. 
  *) 

  if get_mode "types" = Show_off
  then sub 
  else 
    let ty2 = applySub sub ty0
    and ty3 = applySub sub ty1 
    in
    match (ty2,ty3) with
    | TyV _, TyV _ 
    | TyC _, TyC _ when ty2 = ty3 -> sub 
    | (_,TyV (x,_)) when not (mem x fixed) -> addSubCheck sub x ty2
    | (TyV (x,_),_) when not (mem x fixed) -> addSubCheck sub x ty3
    | (ApplyF(g1,f1), ApplyF(g2,f2)) 
    | (Funty(g1,f1), Funty(g2,f2)) -> unify fixed (unify fixed sub g1 g2) f1 f2
    | (Linty f1,Linty f2)
    | (Ref f1, Ref f2) 
    | (Array f1, Array f2) -> unify fixed sub f1 f2 
    | (Quant(x1,f1), Quant(x2,f2)) ->
	let (sub1,x) = freshen_tyvar2 x1 x2 in 
	let sub2 = unify (x::fixed) sub (applySub sub1 f1) (applySub sub1 f2) in 
	if avoid x sub2 
	then sub2
	else typeError [ ty2; ty3] "don't unify"
    | _ -> typeError [ ty2; ty3] "don't unify"
;;



(* allowing covarince of function result types since eager evaluation does not create problems *)

let rec subunify fixed constraints sub ty0 ty1 = 
  (* solve ty0 < ty1 
     If ty0 < x is a constraint then stop else map x to ty0.
     Is this good enough?
*) 

  if get_mode "types" = Show_off
  then sub 
  else 
    let ty2 = applySub sub ty0
    and ty3 = applySub sub ty1 
    in
    match (ty2,ty3) with
    | _,TyC(TyVar "Top",_) -> sub
    | TyV (x,_), ApplyF(g1,f1) when not (mem x fixed) && not (mem x (freeTyVars idSub f1)) -> 
	let ty = TyV(nextTypeVar(),0) in 
	let sub1 = addSubCheck sub x (ApplyF(g1,ty)) in 
	subunify fixed constraints sub1 ty f1 
    | TyV (x,_), Funty(g1,f1) when not (mem x fixed) && not (mem x (freeTyVars idSub f1)) -> 
	let ty = TyV(nextTypeVar(),0) in 
	let sub1 = addSubCheck sub x (Funty(g1,ty)) in 
	subunify fixed constraints sub1 ty f1 
    | ApplyF(g0,f0), ApplyF(g1,f1)
    | Funty(g0,f0), Funty(g1,f1) -> subunify fixed constraints (unify fixed  sub g0 g1) f0 f1
    |_, TyV (x,_) when mem (ty2,x) constraints -> sub 
    | _,_ -> unify fixed sub ty2 ty3 
;;

*)

let rec tymatch  delta sub ty0 ty1 = 
  (* tymatch is a one-sided form of unification.
     delta is the set of variables in ty1 available for matching.
    *) 
 
  if get_mode "types" = Show_off
  then sub 
  else 
 
  let ty2 = applySub sub ty0
  and ty3 = applySub sub ty1 in

  match (ty2,ty3) with
  | TyV _, TyV _ 
  | TyC _, TyC _ when ty2 = ty3 -> sub 
  | (_,TyV (tyv,_))  -> 
      if  List.mem tyv delta
      then TyMap.add tyv ty2 sub 
              (* no need to check since tyv is fresh for ty2 and sub *) 
      else typeError [TyV (tyv,0)] "is not available for matching"
  | (ApplyF(g1,f1), ApplyF(g2,f2))
  | (Funty(g1,f1), Funty(g2,f2)) -> 
      tymatch delta (tymatch delta sub g1 g2) f1 f2
  | (Linty f1, Linty f2)
  | (Ref f1, Ref f2) 
  | (Array f1, Array f2) -> tymatch delta sub f1 f2 
  | _ ->  typeError [ ty2; ty3] "don't match"
;;

let rec tysubmatch delta sub ty0 ty1 = 
  (* tysubmatch is a one-sided form of sub-unification.
     delta is the set of variables in ty1 available for matching.
    *) 
 
  if get_mode "types" = Show_off
  then sub 
  else 

  let ty2 = applySub sub ty0
  and ty3 = applySub sub ty1 in

  match (ty2,ty3) with
  | _,TyC(TyVar "Top",_)  -> sub
  | ApplyF(g0,f0),ApplyF(g1,f1) 
  | Funty(g0,f0),Funty(g1,f1) -> tysubmatch delta (tymatch delta sub g0 g1) f0 f1
  | _,_ -> tymatch delta sub ty2 ty3 
;;


let rec relate sub ty0 ty1 = 
  (* find a substitution that relates ty0 and ty1, 
     which are assumed separated *) 

  if get_mode "types" = Show_off
  then sub 
  else 

  let ty2 = applySub sub ty0
  and ty3 = applySub sub ty1 in

  match (ty2,ty3) with
  | _,TyC(TyVar "Top",_)  
  | TyC(TyVar "Top",_),_ -> sub
  | ApplyF(g0,f0),TyV(tyv,_) 
  | TyV(tyv,_), ApplyF(g0,f0) -> 
      let y = TyV(nextTypeVar(),0) in 
      let sub1 = TyMap.add tyv (ApplyF(g0,y)) sub in 
      relate sub1 f0 y 
  | (ApplyF(g1,f1), ApplyF(g2,f2))
  | (Funty(g1,f1), Funty(g2,f2)) -> 
      let sub1 = unify [] sub g1 g2 in 
      relate sub1 f1 f2 
  | _,_ -> unify [] sub  ty2 ty3 
;;


let rec simplify fixed constraints sub ty0 ty1 = 
  (* produce a substitution upsilon and a constraint C such that 
     if rho ty0 < rho ty1 then rho factors through upsilon and solves C. *) 


  if get_mode "types" = Show_off
  then (sub, None) 
  else 

  let ty2 = applySub sub ty0
  and ty3 = applySub sub ty1 in

  match (ty2,ty3) with
    | _,TyC(TyVar "Top",_) -> (sub, None) 
    | ApplyF(g0,f0), ApplyF(g1,f1) 
    | Funty(g0,f0), Funty(g1,f1) -> 
	simplify fixed constraints (unify fixed  sub g0 g1) f0 f1
    | TyV (x,_), ApplyF(g1,f1) when not (mem x fixed) && not (mem x (freeTyVars idSub f1))  -> 
	let ty = TyV(nextTypeVar(),0) in 
	let (sub1,constraints1) = simplify fixed constraints sub ty f1 in 
	(composeSubs (TyMap.add x (ApplyF(g1,ty)) idSub) sub1, constraints1)
    | TyV (x,_), Funty(g1,f1) when not (mem x fixed) && not (mem x (freeTyVars idSub f1)) -> 
	let ty = TyV(nextTypeVar(),0) in 
	let (sub1,constraints1) = simplify fixed constraints sub ty f1 in 
	(composeSubs (TyMap.add x (ApplyF(g1,ty)) idSub) sub1, constraints1)
    | TyV _, TyV _ when ty2 = ty3 -> (sub,None) 
    | _, TyV (x,_) when mem x (covTyVars idSub ty2) -> (sub, Some (ty2,x))
    | _, TyV (x,_) when mem x (freeTyVars idSub ty2) -> 
	(composeSubs (TyMap.add x (TyC(TyVar "Top",0)) idSub) sub, None) 
    | _, TyV (x,_) -> (sub, Some (ty2,x))
    | _,_ -> (unify fixed sub ty2 ty3 , None) 
;;


(*** case types *)

let is_case_type delta pty sty = 

  (* delta contains possible local tyvars.
     Every tyvar that is free in sty and in delta 
     must be free in pty *) 

  let ptyv = freeTyVars idSub pty 
  and styv = freeTyVars idSub sty 
  in
  let aux b x = b && if mem x delta then mem x ptyv  else true
  in 
  fold_left aux true styv 
;;




(*** method types *) 


let is_simple_method_type delta pty sty = 
  (* delta pty sty must yield a case type.
     Also, any covariant  type variable of pty that is free in sty 
     must be a covariant  type variable of sty. 
   *)
  
  let styv = freeTyVars idSub sty 
  and potyv = covTyVars idSub pty 
  and sotyv = covTyVars idSub sty 
  in
  let aux b x = b && if mem x styv then mem x sotyv else true 
  in 
  fold_left aux (is_case_type delta pty sty) potyv 
;;

let rec dle sEnv sub aty rty = function 
    (* dle is << or type specialisation *) 

    ApplyF(ApplyF(TyC(TyVar "Choice",_),n),m) -> 
      dle sEnv sub aty rty n && (* check the first alternative *) 
      dle sEnv sub aty rty m    (* and the second alternative *) 
  | mty -> 
      match inst_tyscheme mty with         
	Funty(argty2,resty2) -> 
	  let subOpt = 
	    (* try to relate the argument types *) 
	    try Some (relate sub aty argty2)
	    with _ -> None 
	  in 
	  begin 
	    match subOpt with 
	      None -> true (* if the argument types can't be related then okay *) 
	    | Some sub1 -> (* if they can then ... *) 	 
		try let _ = tysubmatch [] sub1 rty resty2 in true 
		with _  -> false 
	  end
      | _ -> false (* if mty is not a function type then no specialisation *) 
;;



let specialises sEnv sub delta aty rty mty = 
  is_simple_method_type delta aty rty &&
  dle sEnv sub aty rty mty
;;


let rec invoke_ty_by_matching sEnv sub uty mty  = 
  (* produces a substitution and a result type, 
     to which the substitution must be applied.
     It will not modify uty 
     *)

  match inst_tyscheme_with_bvars (clos_ty sub sEnv mty) with 
    Funty(pty,sty), delta -> (tysubmatch delta sub uty pty,sty)
  | _ -> typeError [mty] "is not a function or method type"
;;
	  

let rec invoke_ty sEnv sub uty mty  = 
  (* produces a substitution and a result type, 
     to which the substitution must be applied.
     If mty is a function type, 
     i.e. is a the last alternative,
     then any free vars of uty may be instantiated.
   *) 

  match mty with 
  | ApplyF(ApplyF(TyC(TyVar "Choice",_),mty1),mty2) -> 
      begin 
	try invoke_ty_by_matching sEnv sub uty mty1  
	with _ -> invoke_ty sEnv sub uty mty2 
      end
  | _ ->   
      match inst_tyscheme (clos_ty sub sEnv mty) with 
	Funty(pty,sty) -> (subunify [] [] sub uty pty,sty)
      | _ -> typeError [mty] "is not a function or method type"
;;



(*** type inference *)

  (* 
     sEnv provides type (schemes) for  term variables
     sub is a substitution 
     expectedTy is the expected type

     fixed contains fixed type variables. These increase below as follows:
      - let fixed1 = append delta1 fixed
              fixes the type variables of the pattern of a case 
      - let fixed1 = append (freeTyVars sub2 inst_ty) (freeTyVars sub2 sch) 
              fixes the type variables of a polymorphic argument in let rec 
      - let fixed2 = append (freeTyVars sub2 uty2) fixed
              fixes the tyvars of a linear argument 
      - let fixed2 = append delta fixed in 
              fixes the type variables of a polymorphic argument in an application 

*) 
 
(* constructors and datum constants appear in both linear terms  and terms *) 

let infer_constructor_with_delta x sEnv fixed sub0 expectedTy =
  let (n,sch) = 
    try envFind 0 (Var x) globalCEnv
    with Not_found -> termError [Tconstructor (Var x,0)] "is not recognised"
  in 
  let (ty1,delta1) = inst_tyscheme_with_bvars sch  in 
  let sub2 = subunify fixed [] sub0 ty1 expectedTy
  in 
  ((sub2,Tconstructor(Var x,n)),delta1)

let infer_constructor x sEnv fixed constraints sub0 expectedTy =
  fst (infer_constructor_with_delta x sEnv fixed sub0 expectedTy) 

let infer_datum d sEnv fixed constraints sub0 expectedTy = 
  (subunify fixed [] sub0 (cvar (datum_type_string d)) expectedTy,Datum d)



let rec inf_linear p (sEnv: scheme_env) fixed constraints tyEnv theta sub pty_opt = 

  let (pty,delta0) = 
    match pty_opt with 
      None -> 
	let tyv = nextTypeVar() in 
	(TyV(tyv,0), [tyv]) 
    | Some ty -> (ty, freeTyVars sub ty)
  in 	
  match p with 

  | Ptvar x -> 
      let x1 = Var x in 
      let binding = 
	match theta with 
	  Some theta1 -> List.mem x1 theta1
	| _ -> true 
      in 
      if binding 
      then 
	if TMap.mem x1 tyEnv 
	then termError [Tvar(x1,0)] "is a duplicate binding symbol" 
	else 
	  let tyEnv1 = TMap.add x1 (pty,General) tyEnv  in 
	  (sub,Tvar(x1,0),delta0,tyEnv1,pty)
      else 
	let (n,(ty,status)) = 
	  try (0,TMap.find x1 sEnv) 
	  with Not_found -> 
	    try 
	      match envFind 0 x1 globalVEnv with 
		(n,(_,(status0,sch))) -> (n,(inst_tyscheme sch,status0))
	    with _ -> (0,(pty,General))   (* pty is a dummy argument *) 	  
	in 
	begin
	  match status with 
	    Linear -> (sub,Tvar(x1,n),[],tyEnv,ty) 
	  | _ ->  termError [Tvar(x1,0)] "not a linear variable" 
	end


  | Pconstructor x -> 
      let ((sub1,c),delta1) = infer_constructor_with_delta x sEnv [] sub pty 
      in 
      (sub1,c,delta1,tyEnv,pty)

  | Pdatum d -> 
      let (sub1,c) = infer_datum d sEnv [] [] sub pty 
      in 
      (sub1,c,[],tyEnv,pty)

   | Pwildcard str -> 
      begin
	match str with 
	  "" -> (sub,Twildcard "",delta0,tyEnv,pty)
	| "Int" 
	| "Float" 
	| "Char" 
	| "String"  -> (subunify [] [] sub (cvar str) pty,Twildcard str,delta0,tyEnv,pty)
	| "ref"  -> 
	    let x = TyV(nextTypeVar(),0) in 
	    (subunify [] [] sub (Ref x) pty,Twildcard str,delta0,tyEnv,pty)
	| "array"  -> 
	    let x = TyV(nextTypeVar(),0) in 
	    (subunify [] [] sub (Array x) pty,Twildcard str,delta0,tyEnv,pty)
	| _ -> basicError ("_" ^ str ^ " is not a wildcard" )
      end

  | Papply(p1,p2) -> 
      let argty = TyV(nextTypeVar(),0) in 
      let (sub1,q1,delta1,tyEnv1,pty1) = inf_linear p1 sEnv fixed constraints tyEnv  theta sub  (Some (funty argty pty)) in 
      let (sub2,q2,delta2,tyEnv2,pty2) = inf_linear p2 sEnv fixed constraints tyEnv1 theta sub1 (Some argty) in 


      begin
	match applySub sub2 pty1 with 
	| Funty(uty,sty) -> 
	    let sub3 = subunify [] [] sub2 uty pty2
	    in  
	    (sub3,Apply(q1,q2),append delta1 delta2, tyEnv2,sty) 
	| _ -> 
	    let z = nextTypeVar() in 
	    let rty = TyV(z,0) in 
	    let sub3 = unify [] sub2 (funty pty2 rty) pty1 
	    in
	    (sub3,Apply(q1,q2),append delta1 delta2, tyEnv2,rty) 
      end 

  | Poper("as",[p2;p1]) -> 
      let (sub1,q1,delta1,tyEnv1,pty1) = 
	inf_linear p1 sEnv fixed constraints tyEnv theta sub  (Some pty) in 
      let (sub2,q2,delta2,tyEnv2,pty2) = 
	inf_linear p2 sEnv fixed constraints tyEnv1 theta sub1  (Some pty) in 
      let sub3 = unify [] sub2 pty1 pty2 in 
      (sub3,Oper("as",[q2;q1]),append delta1 delta2,tyEnv2,pty1)

  | Poper("view",[t;q]) -> 
      let fixed1 = append delta0 fixed in 
      let qty = TyV (nextTypeVar(),0) in
      let (sub1,t1) = inf t sEnv fixed1 constraints sub  (funty pty qty) in
      let (sub2,q2,delta2,tyEnv2,pty2) = 
	inf_linear q sEnv fixed constraints TMap.empty theta sub1  (Some qty) 
      in 
      (sub2,Oper("view",[t1;q2]),delta2,tyEnv2, pty)

  | Ptyped(p0,(Pnestedclass (str,_,_))) -> 
      if mem str ["Int"; "Float"; "Char" ; "String"] 
      then 
	let the_ty = TyC(TyVar str,0) in 
	let (sub1,p1,delta1,tyEnv1,pty1) = inf_linear p0 sEnv fixed constraints tyEnv theta sub (Some pty) in 
	let sub2 = unify [] sub1 pty1 the_ty
	in (sub2,Oper("as",[p1;Twildcard str]),delta1,tyEnv1,the_ty)
      else 
	let the_pat = pattern_of_class (TyVar str,!declaration_counter) (Pwildcard "")
	in inf_linear (Poper("as",[p0;the_pat])) sEnv fixed constraints tyEnv theta sub (Some pty) 

  | Plam(Ptvar x,p0) -> 
      let ty1 = TyV(nextTypeVar(),0) in 
      let ty2 = TyV(nextTypeVar(),0) in 
      let sub0 = unify [] sub (funty ty1 ty2) pty in        
      begin 
	match theta with 
	  None -> 


	    let (sub1,p1,delta1,tyEnv1,pty1) = inf_linear p0 sEnv fixed constraints tyEnv theta sub0 (Some ty2) 
	    in 
	    if TMap.mem (Var x) tyEnv1 
	    then  (sub1,Lam(Var x,p1),delta1,TMap.remove (Var x) tyEnv1,funty (applySub sub1 ty1) pty1)
	    else pTermError [p] "is not linear"
	| Some vars -> 
	    let (sub1,p1,delta1,tyEnv1,pty1) = inf_linear p0 sEnv fixed constraints tyEnv (Some ((Var x):: vars)) sub0 (Some ty2) in 
	    let argty = 
	      try fst(TMap.find (Var x) tyEnv1)
	      with Not_found -> pTermError [Ptvar x] "is a missing binding symbol"
	    in 
	    (sub1,Lam(Var x,p1),delta1,TMap.remove (Var x) tyEnv1,applySub sub1 (funty argty pty1))
      end

(* it is theoretically possible to allow linear cases, 
   but the benefits are not clear, so don't bother for now. 
   
     | Pcases [(None,p0,None,s0)] -> (* a single, static, case, without a type for the pattern  *) 

      let (sub1,p1,delta1,tyEnv1,pty1) = inf_linear p0 sEnv fixed constraints TMap.empty None sub None 
      in 
      let (sub2,sty) = 
	match applySub sub1 pty with 
          Funty(uty,sty3) ->  
	    let sub3 = subunify [] [] sub1 pty1 uty in 
	    (sub3, sty3)
	| _ -> 
	    let sty3 = TyV(nextTypeVar(),0) in
	    let case_ty = funty pty1 sty3 in 
	    let sub3 = unify [] sub1 case_ty pty in 
	    (sub3,sty3)
      in 
      let theta2 = Some (TMap.fold (fun x _ xs -> x::xs) tyEnv1 [])
      in 
      let (sub4,s4,delta4,tyEnv4,sty4) =  inf_linear s0 sEnv fixed constraints TMap.empty theta2 sub2 None 
      in 
      (sub4,Case(None,p1,s4),delta4,tyEnv4,funty pty1 sty4)
*)

  | _ -> pTermError [p] "is not linear"


and inf = 
  (* 
     inf term (sEnv,fixed,constraints,sub,expectedTy) = (sub',term') 

     term 
     sEnv = scheme environment for free variables in the term
     fixed = tyvars to be fixed in substitution 
     sub = the initial type substitution
     expectedTy = the expected type 
     The arguments need not be  normal wrt the sub 
*)

function 

  | Ptvar x -> infer_var (Var x) 
  | Pwildcard str -> infer_wild str 
  | Pconstructor x -> infer_constructor x 
  | Pdatum d -> infer_datum d 
(* delete ? 
  | Poper ("view",[p1;p2]) -> infer_view p1 p2 
*)
  | Poper ("eqcons",[f;x]) -> infer_eqcons f x 
  | Poper("cond",[b;s;t]) -> infer_cond b s t
  | Poper("prim2string",[t]) -> infer_prim2str t 
  | Poper("printstring",[t]) -> infer_printstring t 
  | Poper("printchar",[t]) -> infer_printchar t 
  | Poper("seq",[u;v]) -> infer_seq u v
  | Poper("assign",[u;v]) -> infer_assign u v 
  | Poper("clone",[t]) -> infer_clone t 
  | Poper("spawn",[t]) -> infer_spawn t
  | Poper("deref",[t]) -> infer_deref t 
  | Poper("while",[b;t]) -> infer_while b t 
  | Poper("lengthv",[v]) -> infer_lengthv v 
  | Poper("entry",[v;t]) -> infer_entry v t 
  | Poper(d,args) -> infer_oper d args 
  | Papply (f, x) -> infer_ap f x 
  | Plam(p,s) -> infer_lam p s
  | Plin (p,s) -> infer_lin p s
  | Pcases cs -> infer_cases cs 
  | Paddcase (x,case) -> infer_add_case (Var x) case 
  | Plet(param,u,t) -> infer_let param u t 
  | Pletrec(param,u,t) -> infer_letrec param u t 
  | Pletext(param,u,t) -> infer_letext param u t
  | Ptyped (t1,ty) -> infer_typed t1 ty  
  | Pnew (tyv,tys) -> infer_new tyv tys
  | PnewArr (t1,t2) -> infer_new_array t1 t2 
  | Pinvoke (t,x,super) -> infer_invoke t x super


and infer_var x sEnv fixed constraints sub0 expectedTy = 
  let (sch,symbol) = 
    try (fst (TMap.find x sEnv),Tvar(x,0))
    with Not_found ->
      try 
	match envFind 0 x globalVEnv with 
	  (_,(_,(Method,sch1)))  -> termError [Tvar (x,0)] "is an attribute"
	| (n,(_,(_,sch1))) ->  (sch1,Tvar(x,n))
      with Not_found -> termError [Tvar (x,0)] "is not recognised"
  in 
  let ty1 = inst_tyscheme (applySub sub0 sch) in 
  let sub2 = subunify fixed constraints sub0 ty1 expectedTy
  in 
  (sub2,symbol)
  
and infer_wild str sEnv fixed constraints sub0 expectedTy = 
    match str with 
      "" -> (sub0,Twildcard "")
    | "Int" 
    | "Float" 
    | "Char" 
    | "String"  -> (subunify fixed constraints sub0 (cvar str) expectedTy,Twildcard str)
    | "ref"  -> 
	    let x = TyV(nextTypeVar(),0) in 
	    (subunify [] [] sub0 (Ref x) expectedTy,Twildcard str)
    | "array"  -> 
	    let x = TyV(nextTypeVar(),0) in 
	    (subunify [] [] sub0 (Array x) expectedTy,Twildcard str)
    | _ -> basicError ("_" ^ str ^ " is not a wildcard" )

and infer_cond b s t sEnv fixed constraints sub0 expectedTy = 
  let (sub1,b1) = inf b sEnv fixed constraints sub0 (cvar "Bool") in 
  let (sub2,s2) = inf s sEnv fixed constraints sub1 expectedTy in 
  let (sub3,t3) = inf t sEnv fixed constraints sub2 expectedTy in 
  (sub3,
   Apply(Choice 
	   (Case(None,Datum(Bool  true),s2),
	    Case(None,Datum(Bool false),t3)),
	 b1))

and infer_prim2str t sEnv fixed constraints sub0 expectedTy = 
  let ty1 = TyV(nextTypeVar(),0) in 
  let (sub1,t1) = inf t sEnv fixed constraints sub0 ty1 in 
  let sub2 = subunify fixed constraints sub1 (cvar "String") expectedTy 
  in 
  (sub2,Oper("prim2string",[t1]))

and infer_printstring t sEnv fixed constraints sub0 expectedTy = 
  let ty1 = cvar "String" in 
  let (sub1,t1) = inf t sEnv fixed constraints sub0 ty1 in 
  let sub2 = subunify fixed constraints sub1 (cvar "Unit") expectedTy 
  in 
  (sub2,Oper("printstring",[t1]))

and infer_printchar t sEnv fixed constraints sub0 expectedTy = 
  let ty1 = cvar "Char" in 
  let (sub1,t1) = inf t sEnv fixed constraints sub0 ty1 in 
  let sub2 = subunify fixed constraints sub1 (cvar "Unit") expectedTy 
  in 
  (sub2,Oper("printchar",[t1]))

and infer_seq u v sEnv fixed constraints sub0 expectedTy = 
  let uty = TyV(nextTypeVar(),0)  in 
  let (sub1,u1) = inf u sEnv fixed constraints sub0 uty in 
  let (sub2,v2) = inf v sEnv fixed constraints sub1 expectedTy in 
  (sub2,Oper("seq",[u1;v2]))

and infer_assign u v sEnv fixed constraints sub0 expectedTy = 
  let dty = TyV(nextTypeVar(),0)  in 
  let (sub1,u1) = inf u sEnv fixed constraints sub0 (Ref dty) (* not infer_field? *) 
  in   
  let (_,bound) = inst_tyscheme_with_bvars (clos_ty sub1 sEnv dty) in 
  let fixed2 = append bound fixed in 
  let (sub2,v2) = inf v sEnv fixed2 constraints sub1 dty in 
  let sub3 = subunify fixed2 constraints sub2 comm expectedTy
  in 
  (sub3,Oper("assign",[u1;v2]))


and infer_clone t sEnv fixed constraints sub0 expectedTy = 
  let (sub1,t1) = inf t sEnv fixed constraints sub0 expectedTy
  in 
  (sub1,Oper("clone",[t1]))

and infer_spawn t sEnv fixed constraints sub0 expectedTy =
  let ty1 = cvar "Unit" in
  let (sub1,t1) = inf t sEnv fixed constraints sub0 ty1
  in
  let sub2 = subunify fixed constraints sub1 (cvar "Unit") expectedTy
  in
  (sub2,Oper("spawn",[t1]))



and infer_deref t sEnv fixed constraints sub0 expectedTy = 
  let (sub1,t1) = inf t sEnv fixed constraints sub0 (Ref expectedTy)
  in 
  (sub1,Oper("deref",[t1]))

and infer_while b t sEnv fixed constraints sub0 expectedTy = 
  let (sub1,b1) = inf b sEnv fixed constraints sub0 (TyC(TyVar "Bool",0)) in 
  let (sub2,t2) = inf t sEnv fixed constraints sub1 comm in 
  let sub3 = subunify fixed constraints sub2 comm expectedTy
  in 
  (sub3,Oper("while",[b1;t2]))

and infer_lengthv v sEnv fixed constraints sub0 expectedTy = 
  let ety = TyV(nextTypeVar(),0)  in 
  let (sub1,v1) = inf v sEnv fixed constraints sub0 (Array ety)  in 
  let sub2 = subunify fixed constraints sub1 (TyC(TyVar "Int",0)) expectedTy 
  in 
  (sub2,Oper("lengthv",[v1]))

and infer_entry v t sEnv fixed constraints sub0 expectedTy = 
  let (sub1,t1) = inf t sEnv fixed constraints sub0 (TyC(TyVar "Int",0)) in
  let ety = TyV(nextTypeVar(),0)  in 
  let (sub2,v2) = inf v sEnv fixed constraints sub1 (Array ety)  in 
  let sub3 = subunify fixed constraints sub2 (Ref ety)  expectedTy
  in 
  (sub3,Oper("entry",[v2;t1]))

and infer_oper d args sEnv fixed constraints sub0 expectedTy = 
  if StringMap.mem d all_ops 
  then 
    let (argtys,str) = StringMap.find d all_ops in 
    let (sub2,args2,argtys2) = 
      infer_op_args sEnv fixed constraints sub0 d args (sub0,[],argtys) in 
    if argtys2 = []
    then 
      let sub3 = subunify fixed constraints sub2 (cvar str) expectedTy in 
      (sub3,Oper(d,args2))
    else basicError (d^" has too few arguments") 
  else basicError (d^" is an unknown operator") 

and infer_op_args sEnv fixed constraints (sub) d = 
  let aux arg (sub,args,argtys) = 
    match argtys with 
      argty :: argtys1 -> 
	let (sub1,arg1) = inf arg sEnv fixed constraints sub (cvar argty) 
	in 
	(sub1,arg1 :: args,argtys1)
    | _ -> basicError (d^" has too many arguments") 
  in 
  fold_right aux 


and infer_view p1 p2 sEnv fixed constraints sub0 expectedTy = 
  let (sub1,p,_,_,_) = inf_linear (Poper("view",[p1;p2])) sEnv fixed constraints TMap.empty (Some []) sub0 (Some expectedTy) in 
  (sub1,p)


and infer_eqcons r u sEnv fixed constraints sub0 expectedTy = 
  let rty = TyV (nextTypeVar(),0) in
  let (sub1,r1) = inf r sEnv fixed constraints sub0 rty in
  let uty = TyV (nextTypeVar(),0) in 
  let (sub2,u2) = inf u sEnv fixed constraints sub1 uty in 
  let sub3 = unify fixed sub2 expectedTy (cvar "Bool") 
  in 	
  (sub3,Oper("eqcons",[r1;u2]))

  
and infer_ap r u sEnv fixed constraints sub0 expectedTy = 
  try infer_ap_arg_first r u sEnv fixed constraints sub0 expectedTy 
  with _ -> infer_ap_fun_first r u sEnv fixed constraints sub0 expectedTy 

and infer_ap_arg_first r u sEnv fixed constraints sub0 expectedTy = 
  let uty = TyV (nextTypeVar(),0) in
  let (sub1,u1) = inf u sEnv fixed constraints sub0 uty in 
  let (sub2,r2) = inf r sEnv fixed constraints sub1 (funty uty expectedTy) 
  in 
  (sub2,Apply(r2,u1))

and infer_ap_fun_first r u sEnv fixed constraints sub0 expectedTy = 
  let rty = TyV (nextTypeVar(),0) in
  let (sub1,r1) = inf r sEnv fixed constraints sub0 rty 
  in 
  let (sub2,u2,uty2) = 
    match applySub sub1 rty with 
      Funty(Linty _,_) -> 
	let (sub3,u3,_,_,uty3) = inf_linear u sEnv fixed constraints TMap.empty (Some []) sub1 None in 
	(sub3,u3,Linty uty3) 
    | _ -> 
	let uty = TyV (nextTypeVar(),0) in 
	let (sub3,u3) = inf u sEnv fixed constraints sub1 uty in 
	(sub3,u3,uty) 
  in 
  match applySub sub2 rty with 

  | Funty(pty,sty) ->
      let (pty2,delta) = inst_tyscheme_with_bvars pty in 
      let fixed2 = append delta fixed in 
      let sub3 = subunify fixed2 constraints sub2 uty2 pty2 in 
      let sub4 = subunify fixed2 constraints sub3 sty expectedTy in  
      let eVars = freeTyVarsInSEnv sub4 sEnv in 
      let sVars = freeTyVars sub4 sty in 
      let nVars = append sVars eVars in 
      let check x = 
	if mem x nVars 
	then typeError [TyV(x,0); applySub sub4 pty2] "should be bindable" 
      in 
      iter check delta;
      (sub4,Apply(r1,u2))

  | _ -> 
      let sub3 = unify fixed sub2 rty (funty uty2 expectedTy)
      in 	
      (sub3,Apply(r1,u2))



and infer_lam p s sEnv fixed constraints sub0 expectedTy = 

  let (x,pty) = 
    match p with 
      Ptvar x  -> (Var x,TyV(nextTypeVar(),0))
    | Ptyped(Ptvar x,pty) -> (Var x,convert_type pty)
    | _ -> pTermError [p] "should be a variable in abstraction" 
  in
  let rty = TyV(nextTypeVar(),0) in 
  let the_ty = funty pty rty 
  in 
  let sub1 = subunify fixed constraints sub0 the_ty expectedTy 
  in
  let sEnv1 = TMap.add x (pty,General) sEnv in    
  let (sub2,s2) = inf s sEnv1 fixed constraints sub1 rty
  in 
  let the_term = Lam(x,s2)
  in 
  (sub2,the_term)


and infer_lin p s sEnv fixed constraints sub0 expectedTy = 


  let (x,pty) = 
    match p with 
      Ptvar x  -> (Var x,TyV(nextTypeVar(),0))
    | Ptyped(Ptvar x,Plinty pty) -> (Var x,convert_type pty)
    | _ -> pTermError [p] "should be a variable of linear type in abstraction" 
  in
  let rty = TyV(nextTypeVar(),0) in 
  let the_ty = Funty(Linty pty,rty)
  in 
  let sub1 = subunify fixed constraints sub0 the_ty expectedTy 
  in
  let sEnv1 = TMap.add x (pty,Linear) sEnv in   
  let (sub2,s2) = inf s sEnv1 fixed constraints sub1 rty
  in 
  let the_term = Lam(x,s2)
  in 
  (sub2,the_term)


and infer_case (xs_opt,p,pty_opt,s) is_att is_default sEnv fixed constraints sub0 default_ty = 

  let theta = 
    match xs_opt with 
      None -> None 
    | Some xs -> Some (List.map (fun x -> Var x) xs) 
  in 
  let ty_opt = 
    match pty_opt with
      None -> None 
    | Some ty -> Some (convert_type ty) 
  in 
  let (sub1,p1,delta1,tyEnv1,pty) = inf_linear p sEnv fixed constraints TMap.empty theta sub0 ty_opt in 
  let sEnv1 = TMap.fold TMap.add tyEnv1 sEnv 
  in 
  if is_att == Method
  then       
    let fixed1 = append delta1 fixed in 
    let sty = TyV(nextTypeVar(),0) in
    let (sub2,s2) = inf s sEnv1 fixed1 constraints sub1 sty 
    in 
    let pty2 = applySub sub2 pty  
    and sty2 = applySub sub2 sty 
    and def2 = applySub sub2 default_ty 
    in 
    if specialises sEnv sub2 delta1 pty2 sty2 def2
    then (sub2,Case(None,p1,s2), funty pty2 sty2)
    else basicError "specialises" 
  else 
    let def1 = applySub sub1 default_ty 
    in 
    match def1 with 
      Funty(uty,tty) ->  
	let (sub2,c_opt) = 
(* delete ?? 
  Why simplify for function extensions. 
Use explicit type coercions if necessary ?

	  if is_default 
	  then (unify fixed sub1 pty uty, None)
	  else simplify fixed constraints sub1 pty uty 
*)
	  (unify fixed sub1 pty uty, None)
	in 
	let constraints2 = 
	  match c_opt with 
	    None -> constraints 
	  | Some p -> p :: constraints 
	in 
	let sVars = freeTyVarsInSEnv sub2 sEnv in 
	let pVars = freeTyVarsInSEnv sub2 tyEnv1 in 
	let dVars = freeTyVars sub2 def1 in 
	let fixed2 = append pVars (append sVars (append dVars fixed)) in
	let (sub3,s3) = inf s sEnv1 fixed2  constraints2 sub2 tty in 
	let case_ty = applySub sub2 (funty pty tty)
	in 
	format_specialisation (applySub sub2 pty); 
	(sub1,Case(theta,p1,s3),case_ty)  
    | _ -> 
	let sty = TyV(nextTypeVar(),0) in
	let case_ty = funty pty sty in 
	let sub2 = unify fixed sub1 case_ty def1 in 
	let (sub3,s3) = inf s sEnv1 fixed constraints sub2 sty in 
	let pty3 = applySub sub3 pty
	and sty3 = applySub sub3 sty in 
	let case_ty3 = funty pty3 sty3 
	in 
	if is_case_type delta1 pty3 sty3
	then (sub3,Case(theta,p1,s3),applySub sub3 case_ty)
	else typeError [case_ty3] "is ill-formed"


and infer_cases cs sEnv fixed constraints sub0 expectedTy = 
  let f (sub1,rest) case = 
	let (sub2,case1,_) = 
	  infer_case case General false sEnv fixed constraints sub1 expectedTy
    in 
    (sub2,Choice(case1,rest))
  in 
  match rev cs with 
    [] -> basicError "no cases in pattern matching function" 
  | case :: cs1 -> 
      let (sub2,case2,_) = infer_case case General true sEnv fixed constraints sub0 expectedTy 
      in 
      fold_left f (sub2,case2) cs1 

and infer_add_case x case sEnv fixed constraints sub0 expectedTy = 
  let (sch,status) = 
   try TMap.find x sEnv
    with Not_found ->
      try 
	let (_,(_,(status1,sch1))) =  envFind 0 x globalVEnv in 
        (sch1,status1) 
      with Not_found -> termError [Tvar (x,0)] "is not recognised"
  in 
  if status !=  Extensible then termError [Tvar (x,0)] "is not extensible";

  let ty1 = inst_tyscheme (applySub sub0 sch) in 
  let sub1 = subunify fixed constraints sub0 (TyV(TyVar "Unit",0)) expectedTy in 
  let (sub2,case2,_) = infer_case case Extensible  false sEnv fixed constraints sub1 ty1
  in 
  (sub2,Addcase(x,case2))


and infer_let param u t sEnv fixed constraints sub0 expectedTy = 
  let (x,uty) = 
    match param with 
      Ptvar x -> (Var x,TyV(nextTypeVar(),0))
    | Ptyped(Ptvar x,ty) -> (Var x,convert_type ty)
    | _ -> pTermError [Plet(param,u,t)] "has a complex let-binding"
  in 
  let (sub1,u1) = inf u sEnv fixed constraints sub0 uty in
  let sch = clos_ty sub1 sEnv uty in 
  let sEnv2 = TMap.add x (sch,General) sEnv in 
  let (sub3,t3) = inf t sEnv2 fixed constraints sub1 expectedTy 
  in 
  (sub3,Tlet(x,u1,t3))


and infer_letrec param u t sEnv fixed constraints sub0 expectedTy = 

  let (x,sch) = 
    match param with 
      Ptvar x -> (x,TyV(nextTypeVar(),0))
    | Ptyped(Ptvar x,pty) -> (x,clos_ty sub0 sEnv (convert_type pty)) 
    |_ -> basicError "Pletrec"  
  in 
  let sEnv1 = TMap.add (Var x) (sch,General) sEnv in 
  let inst_ty = inst_tyscheme sch in 
  let (sub1,u1) = inf u sEnv1 fixed constraints sub0 inst_ty in
  let (sub2,t2) = inf t sEnv1 fixed constraints sub1 expectedTy in 
  let fixed1 = append (freeTyVars sub2 inst_ty) (freeTyVars sub2 sch) in 
  if get_mode "types" = Show_off || 
     let _ = subunify fixed1 constraints sub2 (clos_ty sub2 sEnv inst_ty) (clos_ty sub2 sEnv sch) in true 
  then (sub2,Tletrec(Var x,u1,t2))
  else 
    typeError [applySub sub2 inst_ty] 
      "instantiates bound type variables in inference"

and infer_letext param u t sEnv fixed constraints sub0 expectedTy = 

  let (x,sch) = 
    match param with 
      Ptvar x -> (x,TyV(nextTypeVar(),0))
    | Ptyped(Ptvar x,pty) -> (x,clos_ty sub0 sEnv (convert_type pty)) 
    |_ -> basicError "Pletrec"  
  in 
  let sEnv1 = TMap.add (Var x) (sch,Extensible) sEnv in 
  let inst_ty = inst_tyscheme sch in 
  let (sub1,u1) = inf u sEnv1 fixed constraints sub0 inst_ty in
  let (sub2,t2) = inf t sEnv1 fixed constraints sub1 expectedTy in 
  let fixed1 = append (freeTyVars sub2 inst_ty) (freeTyVars sub2 sch) in 
  if get_mode "types" = Show_off || 
     let _ = subunify fixed1 constraints sub2 (clos_ty sub2 sEnv inst_ty) (clos_ty sub2 sEnv sch) in true 
  then (sub2,Tletext(Var x,u1,t2))
  else 
    typeError [applySub sub2 inst_ty] 
      "instantiates bound type variables in inference"


and infer_typed t1 ty sEnv fixed constraints sub0 expectedTy = 
  let ty1 = convert_type ty in 
  let sub1 = subunify fixed constraints sub0 ty1 expectedTy in 
  inf t1 sEnv fixed constraints sub1 ty1 

and infer_new str args sEnv fixed constraints sub0 expectedTy = 
  let n = !declaration_counter in 
  let class_ty = type_of_class (str,n) (map convert_type args) (TyC(TyVar "Unit",0)) in 
  let sub1 = subunify fixed constraints sub0 class_ty expectedTy in 
  match gTyEnvFind n (TyVar str) with 
  | (_,Class(_,_,new_term)) -> (sub1,new_term  (Tconstructor (Var "Un",0)))
  | _ -> typeError [TyC(TyVar str,n)] "is an unknown class" 

and infer_new_array t n sEnv fixed constraints sub0 expectedTy = 
  let ety = TyV (nextTypeVar(),0) in 
  let (sub1,t1)  =  inf t sEnv fixed constraints sub0  ety in 
  let (sub2,n2) = inf n sEnv fixed constraints sub1  (cvar "Int") in 
  let sub3 = subunify fixed constraints sub2 (Array ety) expectedTy 
  in 	
 (sub3, TnewArr(t1,n2))


and infer_invoke t x super sEnv fixed constraints sub0 expectedTy = 
  let (n,sch) = 
    try       let (n0,(_,(is_att,sch1))) = envFind 0 (Var x) globalVEnv
      in 
      if is_att == Method 
      then (n0,sch1) 
      else raise Not_found
    with Not_found -> termError [Tvar (Var x,0)] "is not a recognised method"
  in 
  let x1 = 
    if super 
    then Tsuper(Var x,n)
    else Tvar(Var x,n)
  in 
  let fty = inst_tyscheme (applySub sub0 sch) in 
  let ty = TyV (nextTypeVar(),0) in
  let (sub1,t1) = inf t sEnv fixed constraints sub0 ty in
  let fty1 = applySub sub1 fty in
  let ty1 = applySub sub1 ty in 
  let (sub2,resty) = invoke_ty sEnv sub1 ty1 fty1 in 
  let sub3 = subunify fixed constraints sub2 resty expectedTy 
  in 	
  (sub3,Apply(x1,t1))


and infer_field sEnv fixed constraints (sub,u) expectedTy = 
  match u with 
  | Ptvar x when TMap.mem (Var x) sEnv -> 
      let ty1 = inst_tyscheme (applySub sub (fst (TMap.find (Var x) sEnv))) in 
      let sub2 = subunify fixed constraints sub ty1 expectedTy
      in 
      (sub2,Tvar(Var x,!declaration_counter))
  
  | Pinvoke (t,x,false) -> 
      let (n,mty) = 
	try 
	  let (n0,(_,(is_att,sch1))) = envFind 0 (Var x) globalVEnv
	  in 
	  if is_att == Method 
	  then (n0,sch1)
	  else raise Not_found
	with Not_found -> 
	  termError [Tvar (Var x,0)] "is not a recognised method"
      in 
      let x1 = Tvar(Var x,n) in 
      let ty = TyV (nextTypeVar(),0) in
      let (sub1,t1) = infer_field sEnv fixed constraints (sub,t) ty in
      let mty1 = applySub sub1 mty in
      let ty1 = applySub sub1 ty in 
      let (sub2,resty) = invoke_ty sEnv sub1 ty1 mty1 in 
      let sub3 = subunify fixed constraints sub2 resty expectedTy 
      in 	
      (sub3,Apply(x1,t1))

  | _ -> pTermError [u] "is not a field"
;;



let infer source ty = 
  let (sub,term) = inf source TMap.empty  [] [] idSub ty 
  in 
  (term,applySub sub ty)
 ;;

let infer_add_case is_att ty case =   
  infer_case case is_att false TMap.empty  [] [] idSub ty
;;



