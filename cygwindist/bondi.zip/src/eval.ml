open List
open Format
open Datum
open P_data
open Environments
open Infer
open Console 
open Parse
open Infer
(*
open Odbc
*)


(*** stores *) 

let store = ref (TMap.empty: value TMap.t) 

let add2store v =  let x = nextvar() in 
  store := TMap.add x v !store; 
  x

let getstore x = 
  try TMap.find x !store
  with Not_found -> Vvar x (* must be a binding variable *) 

let rec addpat = function
    Tvar (x,n) -> add2store (Vvar x)
  | Twildcard str -> add2store (Vwildcard  str)
  | Tconstructor (x,n) -> add2store (Vconstructor(x,n))
  | Datum d -> add2store (Vdatum d)
  | Oper("as",[p1;p2]) -> 
      let x1 = addpat  p1
      and x2 = addpat p2 
      in add2store (Vas(x1,x2))
  | Apply(p1,p2) -> 
      let x1 = addpat  p1
      and x2 = addpat p2 
      in add2store (Vapply(x1,x2)) 
  | p -> termError [p] "not a static pattern" 


let rec getval x = 
(* for diagnostic purposes only *) 
  match getstore x with 
  | Vvar y -> Tvar(y,0) 
  | Vwildcard str -> Twildcard str
  | Vconstructor (y,n) -> Tconstructor (y,n)
  | Vdatum d -> Datum d 
  | Vapply (y,z) -> Apply (getval y,getval z)
  | Vchoice(y,z) -> Choice (getval y,getval z)
  | _ -> Tconstructor (Var "?",0)
;;
 
let nomatch_string = add2store (Vdatum (String "nomatch"))
let exception_location = add2store (Vconstructor (Var "Exception",0))
let nomatch_location = add2store (Vapply(exception_location,nomatch_string))
let un_store = add2store (Vconstructor (Var "Un",0))
let ref_store = add2store (Vconstructor (Var "Ref",0))


let printString x = 
      match getstore x with 
	Vdatum (String s) -> Printf.printf "%s" s;flush stdout 
      | Vwildcard "void" -> Printf.printf "..." ;flush stdout
      | t -> basicError "expected a string"  

let printChar x = 
    match getstore x with 
      Vdatum (Char c) -> Printf.printf "%c" c ;flush stdout 
    | Vwildcard "void" -> Printf.printf "..." ;flush stdout
    | t -> basicError "expected a character"  

(*** evaluation *) 


let rec eval (vEnv,term) =  
  (* produces a location in the store *) 

  match term with 
  | Tvar (x,n) -> evalVar vEnv x n 
  | Tsuper (x,n) -> add2store (Vsuper (evalVar vEnv x n)) 
  | Twildcard str -> add2store (Vwildcard str)
  | Tconstructor (x,n) -> evalConstructor x n  
  | Datum d -> add2store (Vdatum d)
  | Oper("eqcons",[t1;t2]) -> eval_eqcons vEnv (eval(vEnv,t1),eval(vEnv,t2)) 
  | Oper("prim2string",[t1]) -> pToString(eval (vEnv,t1))
  | Oper("printstring",[t1]) -> printString(eval (vEnv,t1)); un_store
  | Oper("printchar",[t1]) -> printChar(eval (vEnv,t1)); un_store
  | Oper("seq",[t1;t2]) -> evalSeq vEnv t1 t2 
  | Oper("assign",[t1;t2]) -> evalAssign (eval(vEnv,t1))(eval(vEnv,t2))
  | Oper("clone",[t1]) -> add2store (getstore (eval(vEnv,t1)))
  | Oper("spawn",[t1]) -> (ignore(Thread.create eval (vEnv,t1)); add2store (Vdatum Un))
  | Oper("deref",[t1]) -> evalDeref (eval(vEnv,t1))
  | Oper("while",[t1;t2]) -> evalWhile vEnv t1 t2 
  | Oper("lengthv",[t1]) -> evalLengthv vEnv  (eval(vEnv,t1))
  | Oper("entry",[t1;t2]) -> evalEntry vEnv (eval(vEnv,t1)) (eval(vEnv,t2))
  | Oper("as",[t1;t2]) -> add2store (Vas(eval(vEnv,t1),eval(vEnv,t2)))
  | Oper("view",[t1;t2]) -> add2store (Vview(eval(vEnv,t1),eval(vEnv,t2)))
  | Oper(d,args) -> eval_oper vEnv d args
  | Apply(x,y) -> evalAp vEnv x y 
  | Lam(x,s) -> add2store (Vlam(x,vEnv,s))
  | Case(theta_opt,p,s) -> eval_case vEnv (theta_opt,p,s)  
  | Choice(s,t) -> eval_choice vEnv s t 
  | Addcase (x,t) -> eval_add_case vEnv x t 
  | Tlet(x,u,s) -> evalLet vEnv x u s 
  | Tletrec(x,u,s) -> evalLetRec vEnv x u s 
  | Tletext(x,u,s) -> evalLetExt vEnv x u s 
  | TnewArr (t,n) -> eval_new_arr (eval (vEnv,t)) (eval (vEnv,n))



and evalVar vEnv x n = 
  if TMap.mem x vEnv 
  then TMap.find x vEnv
  else 
    try fst (snd (envFind n x globalVEnv)) 
    with Not_found -> termError [Tvar(x,n)] "is not recognised" 

and evalConstructor x n = add2store (Vconstructor(x,n)) 

and get_datum vEnv t = 
  match getstore(eval(vEnv,t)) with 
    Vdatum d -> d
  | Vwildcard str -> basicError str
  | _ -> basicError "get_datum" 

and pToString x = 
  let str = 
    match getstore x with 
      Vconstructor (Var x,n) -> x
    | Vdatum x -> string_of_datum_value x
    | Vwildcard str -> "_"^str
    | t -> "..." 
  in 
  add2store (Vdatum (String str))

and evalSeq vEnv t1 t2  = 
  let x1 = eval (vEnv,t1) in 
  match getstore x1 with 
  | Vapply(x2,x3) ->
      begin
	match getstore x2 with 
	  Vconstructor(Var "Exception",0) -> x1 
	| _ -> eval (vEnv,t2)
      end 
  | _ -> eval (vEnv,t2)

and evalAssign x1 x2 = 
  store := 
    TMap.add x1 (Vapply(add2store (Vconstructor (Var "Ref",0)), x2)) !store;
  un_store 

and evalDeref x = 
 try
   match TMap.find x !store with 
     Vapply(z,y) ->  
       begin
	 match TMap.find z !store with 
	   Vconstructor(Var "Ref",_) -> y
	 |_ -> basicError "dereferencing a non-location"  
       end
   |_ -> basicError "dereferencing a non-location"  
 with _ -> basicError "variable not in the store" 

and evalWhile vEnv t1 t2 = 
  match getstore (eval (vEnv,t1)) with 
    Vdatum(Bool true) -> eval (vEnv,Oper("seq",[t2;Oper("while",[t1;t2])]))
  | _ -> un_store

and evalLengthv vEnv x1 = 
  match getstore x1 with 
    Varray xs -> add2store (Vdatum(Int (Array.length xs)))
  | _ -> basicError "not an array" 

and evalEntry vEnv x1 x2 = 
  match (getstore x1,getstore x2) with 
    (Varray xs,Vdatum (Int n)) -> Array.get xs n
  | _ -> basicError "not an array entry" 

and eval_oper vEnv d args = 
  try add2store (Vdatum (eval_datum d (map (get_datum vEnv) args)))
  with 
    Error "void" -> add2store (Vapply(add2store (Vconstructor (Var "Exception",0)), 
				      add2store (Vdatum (String "void"))))
  | Error str -> 
      if get_mode "nomatch" = Show_on 
      then nomatch_location 
      else basicError "a datum operation was mis-applied, perhaps to a wildcard" 

and eval_eqcons vEnv (x1,x2) =
  let yes = 
    match (getstore x1, getstore x2) with 
      Vconstructor (y1,n1), Vconstructor (y2,n2) -> (y1,n1) = (y2,n2)
    | Vdatum y1, Vdatum y2 -> y1 = y2
    | _ -> false 
  in 
  add2store (Vdatum (Bool yes))


and evalAp_opt x0 arg = 
  (* produces a variable option, None for match failure *) 
  match getstore x0 with 
    Vlam(x,vEnv,s) -> Some (eval(TMap.add x arg vEnv,s))
  | Vcase(x,vEnv,s) -> 
      begin 
	match patternmatch (Some vEnv) x arg with 
	  Some vEnv1 -> Some (eval (vEnv1,s))
	| None -> None 
      end

  | Vchoice(x1,x2) -> 
      begin 
	match evalAp_opt x1 arg with 
	  Some y -> Some y 
	| None -> evalAp_opt x2 arg 
      end

  | Vsuper y ->   evalSuper y arg 
  | _ -> Some (add2store (Vapply(x0,arg)))

and evalSuper y arg = 
  match getstore y with 
    Vchoice(y1,y2) -> 
      begin 
	match evalAp_opt y1 arg with 
	  None -> evalSuper y2 arg 
	| Some _ -> evalAp_opt y2 arg 
      end 		     
  | _ -> evalAp_opt y arg 



and evalAp vEnv x y = 
  let z1 = eval(vEnv,x) in 
  let z2 = eval(vEnv,y) in 
  match evalAp_opt  z1 z2 with 
    Some z -> z 
  | None->  if get_mode "nomatch" = Show_on 
	    then nomatch_location 
	    else termError [Apply(getval z1,getval z2)] "is a match failure" 


and patternmatch vEnv xp y = 
(*
  peek_value (getstore xp) "xp";
peek_value (getstore y) "y"; 
*)
  let check_opt b = if b then vEnv else None  
  in 
  match getstore xp with 
  | Vvar x -> 
      begin 
	match vEnv with 
	| None -> None 
	| Some env -> Some (TMap.add x y env) 
      end 
  | Vwildcard "" -> vEnv
  | Vwildcard str -> 
      begin 
	match getstore y with 
	  Vdatum d -> check_opt (str = datum_type_string d)
	| Vapply(x1, _) -> 
	    begin
	      match getstore x1 with 
		Vconstructor (Var "Ref",_) -> check_opt (str = "ref") 
	      | _ -> check_opt false 
	    end
	| Varray _ -> check_opt (str = "array") 
	| Vwildcard str1 -> check_opt (str = str1) 
	|_ -> None 
      end 
  | Vconstructor _  as v -> check_opt (v = getstore y )
  | Vdatum _ as v -> check_opt (v = getstore y) 
  | Vapply(x1,x2) -> 
      begin 
	match getstore y with 
	  Vapply(y1,y2) -> patternmatch (patternmatch vEnv x1 y1) x2 y2
      	| _ -> None 
      end
  | Vas(p1,x) -> 
      begin
	match patternmatch vEnv x y with 
	| None -> None
	| vEnv1 -> patternmatch vEnv1 p1 y 
      end 
  | Vview(x1,x2)  -> 
      begin
	match evalAp_opt x1 y with 
	  Some z -> patternmatch vEnv x2 z 
	| None ->  None 
      end 
  | _ -> None



and eval_case vEnv (theta_opt,p,s) = 
  let x1 = 
    match theta_opt with 
      None -> addpat p 
    | Some theta -> 
	let aux vEnv x = 
	  let y = add2store (Vvar x) in 
	  TMap.add x y vEnv 
	in 
	let vEnv1 = fold_left aux vEnv theta 
	in 
	eval (vEnv1,p)
  in 
  add2store (Vcase(x1,vEnv,s)) 

and eval_choice vEnv t1 t2 = 
  let x1 = eval (vEnv,t1)
  and x2 = eval (vEnv,t2)
  in 
  add2store (Vchoice(x1,x2))

and eval_add_case vEnv x case  = 
  let vcase = eval (vEnv,case) in 
  let y = eval (vEnv,Tvar(x,0)) in 
  let old = nextvar() in 
  store := TMap.add old (getstore y) !store ;
  store := TMap.add y (Vchoice(vcase,old)) !store ;
  un_store

and evalLet vEnv x u s = 
  let y = eval (vEnv,u) in 
  eval (TMap.add x y vEnv,s) 


and evalLetRec vEnv x u s = 
  (* u is evaluated lazily *) 
  let x1 = nextvar() in 
  let vEnv1 = TMap.add x x1 vEnv in 
  let x2 = eval(vEnv1,u) in 
  store := TMap.add x1 (getstore x2) !store; 
  eval(vEnv1,s) 

and evalLetExt vEnv x u s = 
  (* u is evaluated lazily *) 
  let x1 = nextvar() in 
  let vEnv1 = TMap.add x x1 vEnv in 
  let x2 = eval(vEnv1,u) in 
  store := TMap.add x1 (getstore x2) !store; 
  eval(vEnv1,s) 

and eval_new_arr x n = 
  match getstore n with 
    Vdatum (Int n1) when n1 >=0 -> 
      let xs = Array.make n1 (nextvar()) in 
      for i = 0 to n1-1 do 
	Array.set xs i (add2store (Vapply(ref_store,add2store(getstore x))))
      done;
      add2store (Varray xs)
  | _ -> basicError  "non-integer in length of new array" 

(*

and evalTable vEnv = function 
  Apply(Apply(Tconstructor(Var "Pair",_),t1),t2) -> 
    let current_index = eval (vEnv,t1) in 
    let current_int = 
      match getval current_index with 
	Apply(_,Tvar(x2,_)) -> 
	  begin
	    match getval x2 with 
	      Apply(_,Datum (Int n)) -> n 
	    | t -> termError [t] "is the current index value?" 
	  end
      | t -> termError [t] "is the current index?" 
    in 
    let rec aux tbl i = 
      if i < 0 
      then tbl 
      else 
	let vi = eval (vEnv,Apply(t2, Apply(zcvar "Int",Datum (Int i)))) in 
	aux (Table.add i vi tbl) (i-1) 
    in 
    let c = add2store (Vconstructor (Var "Table",0)) in 
    let t = add2store (Vtable (ref (aux Table.empty current_int)))
    in 
    add2store (Vapply(c,t))
  |  _ -> basicError "evalTable"

*)      


;;

let evaluate term =  eval (TMap.empty,term)

let evaluateAp x y = 
    match evalAp_opt  x y with 
      Some z -> z 
    | None ->  basicError  "in evaluateAp" 


  
