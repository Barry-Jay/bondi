
(* type of user commands in shell *)

open Format
open Printf
open Lexing
open Parsing
open List
open Datum
open P_data
open Environments
open Infer
open Declare 
open Eval
open Console
open Dump
open Parse
open Lex
open System

let initial_type_environment() =
  (* dropped "pairF" *) 
  let g name = gTyEnvAdd (TyVar name) 0 (Synonym(cvar name))
  in 
  iter g initial_types 
;;


let constructors = 
  [
   ("Un", cvar "Unit");

  (let x = nextTypeVar() in 
  ("Exception", Quant(x,TyV(x,0))));

   (let x = nextTypeVar() in 
   let y = TyV(x,0) in 
   ("Ref", Quant(x,funty y (Ref y)))) ;

 ]


let add_constructors (name,sch) = 
  envAdd (Var name) 0 sch globalCEnv ;;


let initial_term_environment() = 
List.iter add_constructors constructors



(*** General *)

let input_channel_line chan () = input_line chan;;

let parseShellListFromChannel chan =
  Lex.runParser
    Parse.parseShellActionList
    (Lexing.from_function (Console.std_lexer_func (input_channel_line chan)))



(*** %use *)

let rec load_source base_name full_name =
  let save_modes = !modes in
  modes := ("prompt", Show_off) :: ("echo", Show_off) :: !modes;
  let chan = open_in full_name in
  try
    List.iter process_action (parseShellListFromChannel chan);
    provide base_name; 
    close_in chan
  with e ->
    modes := save_modes;
    close_in chan;
    raise e

and process_action action = 
    f_string_tbl := [];
    f_counter := "";

    match action with
    | Quit_directive ->                   printf "\b~~~\n"; exit 0
    | Show_directive (mode,s) ->          set_mode s mode
    | Cd_directive dir ->                 chdir dir
    | Let_decl(identifier,(Pletext(_,_,_) as sourceTerm)) -> 
	let _ = get_declaration_counter() in 
	declare Extensible identifier sourceTerm
    | Let_decl(identifier,sourceTerm) -> 
	let _ = get_declaration_counter() in 
	declare General identifier sourceTerm
    | Lin_decl(identifier,sourceTerm) -> 
	let _ = get_declaration_counter() in 
	declare Linear identifier sourceTerm
    | Add_decl(thefun,pattern,sourceTerm, is_method) -> 
	let _ = get_declaration_counter() in 
	if is_method
	then add_decl Method thefun pattern None sourceTerm 
	else add_decl Extensible thefun pattern None sourceTerm 
    | Let_type decl ->  
	let _ = get_declaration_counter() in 
	declare_type decl 
    | Let_type_synonym (identifier,ty) -> 
	let _ = get_declaration_counter() in 
	declare_type_synonym identifier ty
    | Let_class (tyv,args,super_opt,(mds,add_cases)) -> 
	let _ = get_declaration_counter() in 
	declare_class tyv args super_opt mds add_cases
    | Use_directive (force, s)  -> 
        let basename =
          let sansdir =
            try
              let i = String.rindex s '/' in
              String.sub s (i + 1) (String.length s - i - 1)
            with Not_found -> s
          in
          strip_file_name_extension sansdir
        in
        if force 
	then do_general_load load_source load_dump basename s 
	    (* used to be load_source basename s  
	       but this didn't pick up the path *) 
	else
        if is_loaded basename then () else
        do_general_load load_source load_dump basename s
;;



(*** Top level loop *)



let error_stop_mode = ref false

let handleTopLoopException exn = 
  begin match exn with

  (* system-defined *)

  | Invalid_argument s -> pf (sprintf "Invalid_argument %s" s)
  | Sys_error s -> pf s
  | Sys.Break -> pf "Break ..."
  | Not_found -> pf "Not_found"

  (* failures in named O'Caml functions *)

  | Failure s -> pf (sprintf "Failure in %s" s)

  (* exported from source files *)

  | Lex.SyntaxError (line,col,message) ->  
      Printf.printf "Syntax error at line %d, column %d : %s"
            line col message; 
  | Error s       -> Printf.printf "error: %s" s
  | PtypeError (tys,s) -> formatTypeError idSub (map convert_type tys,s)
  | TypeError (tys,s) -> formatTypeError idSub (tys,s)
  | PTermError (ts,s)  -> formatPTermError (ts,s)
  | TermError (ts,s)  -> formatTermError (ts,s)
  | Wrong_index m -> 
      Printf.printf "index %d is too small in the environment" m
  | e -> Printf.printf "Unexpected exception: %s" (Printexc.to_string e)
  end;
  if !error_stop_mode then exit 1
;;

let makeConsoleLexbuf () =
  Lexing.from_function
    (if isatty () then readline_lexer_func else std_lexer_func read_line)
;;


let readEvalPrint () =
  let mode x = get_mode x = Show_on in
  let parseShell = Lex.runParser Parse.parseShellAction
  in
  let lexbuf = ref (makeConsoleLexbuf ()) in
  Console.set_ps1 "~~ ";
  Console.set_ps2 "";
  while (true) do
    Console.set_stdin_prompt_mode (mode "prompt");
    Console.set_stdin_echo_mode (mode "echo");
    Console.set_stdin_number_mode (mode "number");
    Console.set_start();
    try
      let action = parseShell !lexbuf
      in process_action action
    with exn ->
      handleTopLoopException exn;
      flush stdout;
      print_newline();
      lexbuf := makeConsoleLexbuf ()
  done
;;


(* [withLocalFileState name f x]
   Compute and return [f x] in a local file state. *)
let withLocalFileState name f x =
  let save_line_number = !Lex.line_number and save_modes = !modes in
  try
    Lex.line_number := 1;
    let y = f x in
    Lex.line_number := save_line_number; modes := save_modes; y
  with e ->
    Lex.line_number := save_line_number; modes := save_modes; raise e


let rec general_load given_name =
  let base_name = strip_file_name_extension given_name in
  try
    withLocalFileState given_name
      (do_general_load load_source load_dump base_name) given_name
  with e ->
    handleTopLoopException e;
    Printf.printf "Error processing %s, continuing\n" given_name;
    flush stdout;
    exit 1

let theShell () =
  let command_line =
    if !Sys.interactive
    then {cl_std = true; cl_errorstopmode = false; cl_files = []}
    else parse_command_line Sys.argv
  in
  let interactive = command_line.cl_files = [] && isatty () in
  error_stop_mode := command_line.cl_errorstopmode;
  let startUps = if command_line.cl_std then ["prelude/standard_prelude"] else [] in
  Sys.catch_break true;
  initial_type_environment();
  initial_term_environment();


  if startUps <> [] then begin
    if interactive then pf "Loading startup files ... ";
    List.iter general_load startUps
  end;
  if interactive then begin
    pf "" ;
    pf "" ;
    pf ("Welcome to bondi version " ^ System.version);
    pf "No warranty expressed or implied" ;
    pf ("Standard library: " ^ System.standard_library);
    pf "See README for details" ;
    pf "type `%quit;;' to exit" ;
    set_mode "echo" Show_on;
    set_mode "prompt" Show_on;
  end;
  if command_line.cl_files = [] then readEvalPrint () 
  else
  List.iter general_load command_line.cl_files
;;

let () =
  Random.init (truncate (Unix.gettimeofday ()));
  if !Sys.interactive then
    print_endline "Type \"Shell.theShell ();;\" to start a session."
  else theShell ()
;;
