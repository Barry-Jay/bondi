(* Module [Console]: user and operating system interface *)

open Datum 
open P_data

let version_number =  System.version;;

(*** Console *)

(* construct a console lexer object:
   if stdin is a terminal, use gnu_readline if available,
   else, stdin is redirected, just use a standard lexer
 *)

(* buffer to store string in *)
let buffer = ref "";;

let ps1 = ref "~~ ";;
let ps2 = ref "> ";;
let (prompt:string ref) = ref !ps1;;

let set_ps1 s = ps1 := s;;
let set_ps2 s = ps2 := s;;
let set_start() = prompt := !ps1;;
let get_prompt() = 
  let tmp = !prompt in
    prompt := !ps2;
    tmp
;;

let readline_lexer_func (s:string) (maxfill:int) =
  begin (* prime the buffer *)
    if !buffer = "" then
      buffer := Config.readline (get_prompt()); 
  end;

  let buffer_length = String.length !buffer in
  let toCopy = min maxfill buffer_length in
    String.blit !buffer 0 s 0 toCopy; (* blit the head across *) 
    buffer := String.sub !buffer toCopy (buffer_length - toCopy); 
      (* cut it out of the buffer *)
    toCopy
;;


let prompt_switch = ref false;;
let echo_switch = ref false;;
let number_switch = ref false;;
let line_number = ref 0;;

let set_stdin_prompt_mode (value:bool) = 
  prompt_switch := value;;

let set_stdin_echo_mode (value:bool) = 
  echo_switch := value;;

let set_stdin_number_mode (value:bool) = 
  number_switch := value;;

let std_lexer_func get_line (s:string) (maxfill:int)  =
  begin (* prime the buffer *)
    if !buffer = "" then begin
      if !prompt_switch then begin
        if !number_switch 
        then print_string (" " ^ (string_of_int !line_number));
        print_string (get_prompt()) 
      end;
      flush stdout;

      begin
        try 
          buffer := (get_line() ^ "\n"); 
          incr line_number
        with  _ ->  buffer := ""
      end;
      
      if !number_switch & not !prompt_switch 
      then print_string ((string_of_int !line_number) ^ ": ");
      
      if !echo_switch then begin
        print_string !buffer; 
        flush stdout
      end
    end
  end;

  let buffer_length = String.length !buffer in
  let toCopy = min maxfill buffer_length in
    String.blit !buffer 0 s 0 toCopy; (* blit the head across *) 
    buffer := String.sub !buffer toCopy (buffer_length - toCopy); 
      (* cut it out of the buffer *)
    toCopy 
;;

let line_from_channel (chan:in_channel) =
  try ((input_line chan) ^ "\n")
  with _ -> ""
;;

  
let isatty = Config.isatty;;




(*** Filesystem *)

let chdir dir =
  Sys.chdir dir; (* raises [Sys_error message] if it fails *)
  print_endline ("New directory: " ^ Sys.getcwd ())


let fileInRunDirectory filename = "./" ^ filename  (* Unix *)


let strip_file_name_extension full =
  let l = String.length full in
  if l <= 4 then full else
  if (full.[l-4] == '.' && full.[l-3] == 'f' &&
      (full.[l-2] == 's' && full.[l-1] == 'h' ||
      full.[l-2] == 'r' && full.[l-1] == 'z'))
  then String.sub full 0 (l - 4)
  else full


let basic_path = "." :: (try [System.standard_library] with Not_found -> [])

type kind_of_file = Unknown | Source | Frozen
let file_exists = Sys.file_exists

(* Maybe also try [name ^ ".frz"] and [name ^ ".bon"] *)
let load_any load_source load_dump base_name name =
  let use kind_of_file base_name full_name =
    let actually_load, action_text =
      match kind_of_file with
        Frozen -> load_dump, "thawing"
      | _ -> load_source, "sourcing"
    in
    Printf.printf "(* Begin %s \"%s\"... *)\n" action_text full_name;
    flush stdout;
    actually_load base_name full_name;
    Printf.printf "(* Finished %s \"%s\" *)\n" action_text full_name;
    flush stdout;
    ()
  in
  let kind_of_file =
    let l = String.length name in
    if l >= 4 && name.[l-4] == '.' && name.[l-3] == 'f' then
      if name.[l-2] == 's' && name.[l-1] == 'h' then Source else
      if name.[l-2] == 'r' && name.[l-1] == 'z' then Frozen else
      Unknown
    else Unknown
  in
  if file_exists name then
    use kind_of_file base_name name
  else match kind_of_file with
    Source | Frozen -> raise Not_found
  | Unknown ->
      let frozen = name ^ ".frz" in
      if file_exists frozen then use Frozen base_name frozen else
      let source = name ^ ".bon" in
      if file_exists source then use Source base_name source else
      raise Not_found

(* Look up [name] in [basic_path] unless it matches m"^\.*/" *)
let do_general_load load_source load_dump base_name given_name =
  try
    for i = 0 to String.index given_name '/' - 1 do
      if given_name.[i] != '.' then raise Not_found
    done;
    (* Absolute or explicitly relative path (m"^\.*/") *)
    try load_any load_source load_dump base_name given_name
    with Not_found -> print_endline ("File not found: " ^ given_name)
  with Not_found ->
    (* Implicit relative path (not m"^\.*/") *)
    try
      List.iter
        (function dir ->
          try
            load_any load_source load_dump
              base_name (Filename.concat dir given_name);
            raise Exit
          with Not_found -> ())
        basic_path;
      print_endline ("File not found: " ^ given_name)
    with Exit -> ()




(*** Modes *)

let show_off = Show_off
let show_on = Show_on

(* The optimisations are all beneficial. The mode switches are there to allow
     quantification of their benefits. *)

let modes = ref [               (* list of string/default pairs *)
  "concrete",   show_off;        (* make taged forms abstract *) 
  "declaration", show_on;       (* do show type of declared entity *)
  "echo",       show_off;       (* do not echo redirected standard input *)
  "eval",       show_on;        (* evaluate *) 
  "infer",      show_off;       (* do not display inferred term *)
  "lintypes",   show_on;        (* show linearity of types *) 
  "number",     show_off;       (* put line numbers on echoed lines *)
  "parse",      show_off;       (* do not display parse trees *)
  "prompt",     show_off;       (* do not show a prompt *)
  "specialise", show_off;       (* hide specialisation details *) 
  "types",      show_on;         (* use types *) 
  "nomatch",    show_off;        (* match failure as a bondi exception not an ocaml exception *) 
  "declaration_index", show_off (* show the declaration index when formatting *) 
] ;;


let is_nonempty_prefix s1 s2 =  (* prefixes of mode names will suffice,
                                   except for "assign" *)
  let s1_len = String.length s1
  and s2_len = String.length s2
  in
  if s1_len = 0 or s1_len > s2_len
  then false
  else s1 = String.sub s2 0 s1_len
;;

let set_mode s mode =
  let rec loop = function
      [] -> basicError ("no such mode: " ^ s)
    | (name,curr)::t ->
        if is_nonempty_prefix s name
        then (name,mode)::t
        else (name,curr)::(loop t)
  in
  modes := loop (!modes);
;;

let safe_set_mode s mode =
  try set_mode s mode with
    Error message -> print_endline ("Warning: " ^ message)

let get_mode s =
  try List.assoc s !modes
  with Not_found -> basicError "unrecognised mode"
;;

let parse_modes s0 =
  let s = s0 ^ " " in
  let l = String.length s in
  let badly_formed = ref false in
  let rec parse i =
    if i == l then () else match s.[i] with
      ' '|':' -> parse (succ i)
    | '-' -> set show_off (succ i) (succ i)
    | '+' -> set show_on (succ i) (succ i)
    | _ -> badly_formed := true
  and set setting i j =
    match s.[j] with
      'A'..'Z'|'a'..'z'|'_' -> set setting i (succ j)
    | _ -> set_mode (String.sub s i (j - i)) setting; parse j
  in
  parse 0;
  if !badly_formed then print_endline "Warning: badly formed mode list";
  ()




(*** Command line *)

let help_text =
  Printf.sprintf "Usage: %s [OPTION]... [FILE]...%s%s%s%s%s%s"
    Sys.argv.(0)
    "\n  -e, --errorstopmode   Abort with nonzero exit code on any error"
    "\n  -f, --fast            Do not load the standard prelude"
    "\n  -h, --hide MODE       Set MODE to Show_off"
    "\n  -s, --show MODE       Set MODE to Show_on"
    "\n      --help            Display this help and exit"
    "\n      --version         output version information and exit"

let print_and_exit s =
  print_endline s;
  flush stdout;
  exit 0

type command_line = {
    mutable cl_std : bool;              (* Load the standard prelude? *)
    mutable cl_errorstopmode : bool;    (* Halt on any error? *)
    mutable cl_files : string list;     (* Files to run *)
  }

let parse_command_line argv =
  let cl =
    { cl_std = true;
      cl_errorstopmode = false;
      cl_files = [] }
  in
  let rec parse = function
      [] -> cl.cl_files <- List.rev cl.cl_files
    | "--" :: more -> cl.cl_files <- List.rev_append cl.cl_files more
    | "" :: tail -> parse tail
    | filename :: tail when filename.[0] != '-' ->
        cl.cl_files <- filename :: cl.cl_files; parse tail
    | "--version" :: _ -> print_and_exit ("bondi v. " ^ version_number)
    | "--help" :: _ -> print_and_exit help_text
    | ("-e"|"--errorstopmode") :: tail ->
        cl.cl_errorstopmode <- true; parse tail
    | ("-f"|"--fast") :: tail -> cl.cl_std <- false; parse tail
    | ("-h"|"--hide")::mode :: tail -> safe_set_mode mode show_off; parse tail
    | ("-s"|"--show")::mode :: tail -> safe_set_mode mode show_on; parse tail
    | option :: tail ->
        print_endline ("Warning: ignoring option " ^ option); parse tail
  in
  parse (List.tl (Array.to_list argv));
  cl


(* End of file console.ml. *)
