

(* restore !!

(* functors *)


(* 1. for each functor fr and tuple of types xs find
   c: fr -> g xs and e : g xs -> fr *)


let rec extract xs fr = 
  if sequence_diff 
      (freeTyVars idSub fr) 
      (freeTyVars idSub xs) = (freeTyVars idSub fr) 
  then (apF (fvar "konstant") fr,zvar "Evr", zvar "elimEvr")
  else 
    match fr with 
      TyV(x,_) -> 
      	begin
      	  match xs with 
	    TyV(y,_) -> (fvar "ident",zvar "Ths",zvar "elimThs") 
      	  | ApplyF(ApplyF(TyV(TyVar "pairF",_),x1),x2) -> 
	      if List.mem x (freeTyVars idSub x1) 
	      then 
	      	let (g,c,e) = extract x1 fr in 
	      	(apF (fvar "left") g,
		 cmp2 (zvar "Asl") c,
		 cmp2 e (zvar "elimAsl"))
	      else 
	      	let (g,c,e) = extract x2 fr in 
	      	(apF (fvar "right") g,
		 cmp2 (zvar "Asr") c,
		 cmp2 e (zvar "elimAsr"))
      	  | _ -> typeError [xs] "extract" 
      	end

    | ApplyF(fr1,fr2) -> 
      (* assume that there are no xs in fr1 *)
      	if fr2 = xs 
      	then (fr1,identity,identity)
      	else 
      	  let (gs,cs,es) = extract_tuple xs fr2 in 
	  let x = nextvar() 
	  and y = nextvar() in 
      	  add_rep (
	  apF (fvar "right") fr1,gs,
	  lam2 (Binding x) (ap (zvar "Asr") (Oper("map",[cs;Free(x,0)]))),
	  lam2 (Binding y) (Oper("map",[es;ap (zvar "elimAsr") (Free(y,0))]))
	    )

    | Funty _    
    | Wedge _ 
    | Class _ -> typeError [fr] "extract" 

and extract_tuple xs = function 
    ApplyF(ApplyF(TyV(TyVar "pairF",_),fr1),fr2) ->
      let (g1,c1,e1) = extract_tuple xs fr1
      and (g2,c2,e2) = extract_tuple xs fr2 in 
      (pairF g1 g2,ap2 (zvar "Bthfun") c1 c2, ap2 (zvar "Bthfun") e1 e2)
  | fr -> 
      let (g,c,e) = extract xs fr in 
      (g,ap (zvar "Onefun") c, ap (zvar "Onefun") e)

and add_rep (g,fr,c,e) =
  match fr with 
    ApplyF(ApplyF(TyV(TyVar "pairF",_),fr1),fr2) ->
      add_rep (apF2 (fvar "replicate1") g fr1,
	       fr2,
	       cmp2 (zvar "Rpp") c,
	       cmp2 e (zvar "elimRpp"))
  | _ -> (apF (apF (fvar "replicate") g) fr,
	  cmp2 (zvar "Rep") c,
	  cmp2 e (zvar "elimRep"))
  
let extract_all xs frs = 

 match rev frs with 
(* were they already reversed in the parser ?? *)
    [] -> (apF (fvar "konstant") (fvar "unit"),  
	   ap (zvar "Evr") (zvar "Un"), [],[]) 
  | [fr] -> 
      let (g0,c0,e0) = extract xs fr in
      let tv = nextvar() in 
      (g0,ap c0 (Free(tv,0)),[e0],[Binding tv])

  | fr0::frs0 -> 
      let the_fun (g1,c1,es1,params) fr0 = 
      	let tv = nextvar() in 
      	let (g0,c0,e0) = extract xs fr0  in 
      	(apF (apF (fvar "param_product") g0) g1,
	 ap2 (zvar "Bind") (ap c0 (Free(tv,0))) c1,
	 (cmp2 e0 (zvar "elimBind1")) :: 
	 (List.map (fun e -> cmp2 e (zvar "elimBind2")) es1),
	 (Binding tv)::params)

in 
      let (g0,c0,e0) = extract xs fr0 in 
      let tv = nextvar() in 
      fold_left the_fun (g0,ap c0 (Free(tv,0)),[e0],[Binding tv]) frs0
;;

let extract_all_all decs = 
  let aux  (params,abstrs) = 
    match rev params with   (* simplify? produce the_functor here ? *) 
      [] -> typeError [] "extract"
    | args :: _ -> 
	(params, 
	 List.map (fun (abs,frs) -> (abs,frs,extract_all args frs)) abstrs) 
  in 
  List.map aux decs
;;

*)

let is_primitive_record = function 
             (* fragile!! Primitive types must not be re-defined *)
    "Un"
  | "Evr"
  | "Ths"
  | "Bind"
  | "Asl"
  | "Asr"
  | "Rep"
  | "Rpp"  -> true
  | _ -> false
;;

let is_primitive = function 
             (* fragile!! Primitive types must not be re-defined *)
    "True"
  | "False"
  | "Tag" -> true 
  | t -> is_primitive_record t
;;


    
let qfunty_with_tyvars tvs fr ty  = 
(* !! This must be modified to bind type variables *) 
  let fr1 = convert_type fr in 
  let checkvar tv b = b && (List.mem tv tvs || TyMap.mem tv !globalTyEnv || TyMap.mem tv !globalClassEnv )
  in 
  if TyVarSet.fold checkvar (freeTyVars idSub fr1) true
  then funty fr1 ty (* what are the binding variables ? *) 
  else typeError [fr1] "has uncontrolled type variables" 
;;


(* restore ?? 

(* fromAbstractToString *)

let fromAbstractToString_sch = 
  let x = nextTypeVar()
  and y = nextTypeVar()
  and z = nextTypeVar()
  in 
  let tvs = TyVarSet.add x (TyVarSet.add y (TyVarSet.add z TyVarSet.empty)) 
  in 
  Funty(funty (TyV(x,0)) (TyV(y,0)),[x;y;z],funty (apF (TyV(x,0)) (TyV(z,0))) string)
;;

let fromAbstractToString_cases = ref (Tconstructor (Tvar "Exception"))
;;

envAdd (Var "fromAbstractToString") 0 (Data_structure(Vvar(Var "exn",0,fromAbstractToString_sch))) globalVEnv
;;

let make_abstract_case abs es = 
  let x = nextvar() in 
  let f y z = 
    ap2 (Pconstructor "Cons") 
      (Datum(Char ' ')) 
      (ap2 (Free(Var "append",0)) 
	 (ap2 (Free(Var "toPrimString",0)) (ap y (Free(x,0))) (bon_true))
	 z
	 )
  in 
  Vpm([],[x,],TMap.empty,
  Binding x,
  ap2 (Free(Var "append",0)) 
    (bondistring abs) 
    (fold_right f es (zvar "Nil")),
  nomatch 
       ) 
;;


let f y z = Cons ' '  (append (toPrimString (y x) true) z)

let declare_data_type tyv ctr decs =

  let one_dec = length decs <= 1 in 

  let aux (params,abstrs0) = 

    let one_abstractor = length abstrs0 <= 1 in 

    let (dty,paramvars) = 
      fold_left apF_with_tyvars (TyV(tyv,ctr),TyVarSet.empty) params in 

    let (the_functor,args) = 
      match dty with 
       	ApplyF(fr,xs) -> (fr,xs) 
      | _ -> typeError [dty] "is not an application" 
    in 

    let aux0 (abs,frs,(g,c0,es,params))  =
   (* abstrs is a list of (abstractor, functor) pairs *)
      let abs_ty = (fold_right (funty_with_tyvars paramvars) frs dty) in 
      let abs_sch = closTy idSub TMap.empty  abs_ty in 
      let status = 
	if one_dec && one_abstractor 
	then Record
	else Linear 
      in
      if is_primitive abs
      then envAdd (Var abs) 0 
	  (abs_sch, status,Free(Var abs,0)) globalCEnv
      else 
	begin
       	  let nm_str = abs ^ "_name" in
       	  let nm_var = Var nm_str in 
       	  let nm = Free(nm_var,ctr) in 
       	  let nm_ty = (funty g the_functor) in 
       	  let nm_sch = closTy idSub TMap.empty  nm_ty in 
       	  let c =  multilam2 params (ap2 (zvar "Tag") nm c0) in 
       	  envAdd nm_var ctr (nm_sch,status,nm) globalTEnv;
       	  envAdd (Var abs) ctr (abs_sch,status,c) globalTEnv;

(* adding a case to make_abstract *)


	  if List.mem abs ["Pair";"Nil";"Cons";"String"]
	  then () 
	  else 
	    begin
	      fromAbstractToString_cases := 
		 Extend(TMap.empty,Free(nm_var,ctr), 
		    	make_abstract_case abs es,
		    	!fromAbstractToString_cases);
	      envAdd (Var "fromAbstractToString") 0 
	      	(fromAbstractToString_sch,Common,!fromAbstractToString_cases) 
		globalTEnv
	    end 
	end 
    in 
    List.iter aux0 abstrs0
  in 
  List.iter aux decs
;;

end restore?? *)
