(* Module [Dump]: Partial or total dumps of the FISh environments *)

open Environments


type pack = {
    functors : type_env;
    terms : value_env
  }
    (* Do not change the order of fields, or you will not be able to use old
       dumps. *)



(*** Tools *)

module Ordered_string =
  struct 
    type t = string 
    let compare = Pervasives.compare 
  end

module Encodings = Map.Make(Ordered_string)

module String_Set =
  Set.Make(struct type t = string let compare = Pervasives.compare end)


exception Premature_end_of_file
    (* The end of the file was reached before the end of the frozen pack. *)
exception Checksum_mismatch
    (* The checksum for the frozen pack does not match, the file is corrupt. *)
exception Invalid_format of string
    (* The file contains something, but this is not a frozen pack.
       The string is an explanatory message, not necessarily useful. *)

(*** %require *)

let features = ref String_Set.empty
let is_loaded name = String_Set.mem name !features
let provide name = features := String_Set.add name !features

let id x = x

(* [string_fields_stream c s] ==> [s]
   Make a stream of fields of [s]. A field of [s] is a maximal substring not
   containing the character [c], and either not empty or not a suffix. *)
let string_fields_stream c text =
  Stream.from
    (let r = ref 0 and l = String.length text in function _ ->
      if !r == l then None else Some
        (let r0 = !r in try
          r := String.index_from text !r c + 1;
          String.sub text r0 (!r - r0 - 1)
        with Not_found -> r := l; String.sub text r0 (l - r0)))

(* [hex_of_string s] ==> [h]; [string_of_hex h] ==> [s]
   Convert between [h], an arbitrary string, and a hexadecimal
   representation. Assume characters have 8 bits. *)
let hexadecimal_digits = "0123456789abcdef"
let hex_of_string s =
  let n = String.length s in
  let h = String.create (2 * n) in
  let rec back i j =
    if i != -1 then
      let x = Char.code s.[i] in
      h.[j] <- hexadecimal_digits.[x land 0x0f];
      h.[j-1] <- hexadecimal_digits.[(x land 0xf0) lsr 4];
      back (i - 1) (j - 2)
  in
  back (n - 1) (2 * n - 1); h

let int_of_hex_digit = function
    '0'..'9' as c -> (Char.code c) land 0x0f
  | ('A'..'F') as c -> (Char.code c) - 55
  | ('a'..'f') as c -> (Char.code c) - 87
  | _ -> invalid_arg "Dump.string_of_hex"
let string_of_hex h =
  let nn = String.length h in
  if nn land 1 != 0 then invalid_arg "Dump.string_of_hex";
  let n = nn lsr 1 in
  let s = String.create n in
  let rec back i j =
    if i != -1 then begin
      s.[i] <- Char.chr (((int_of_hex_digit h.[j-1]) lsl 4) lor
                         (int_of_hex_digit h.[j]));
      back (i - 1) (j - 2)
    end
  in
  back (n - 1) (nn - 1);
  s

(* [stream_weak_next default s] ==> [x]
   Like [Stream.next], but return [default] at the end of the stream. *)
let stream_weak_next default = fun x -> default 

(* disabled in changing to ocaml3.06 
parser
    [< 'x >] -> x
  | [<>] -> default
*)


(* [input_significant_line chan] ==> [s]
   Return the first significant line in [chan].
   A line is considered significant if it is not empty and does not begin
   with '#'. *)
let rec input_significant_line chan =
  let line = input_line chan in
  if String.length line == 0 || line.[0] == '#'
  then input_significant_line chan
  else line







(*** File format *)

let encodings =
  List.fold_left
    (fun m (k,x,y) -> Encodings.add k (x,y) m) Encodings.empty
    ["plain", id, id;
     "", id, id]


(* Format FISh0001:
   "FISh0001:${tag}:${length}:${sum}:${name}:${encoding}:${IGNORED}\n".
   "${representation}"
   ${tag} =~ /^[ -9<-~]+$/, ${tag} begins at the beginning of a line
   ${length} =~ /^[0-9]+$/
   ${sum} =~ /^[0-9A-Fa-f]{32}$/
   ${name} =~ /^[^\000-\037:;\177]+$/
   ${encoding} =~ /^[ -9<-~]+$/
   ${representation} is ${length} characters long
 *)
(* Format FISh0002:
   dump_file ::= head_comment header_line charset content
   head_comment ::= comment_line*
   comment_line ::= /\#.*\n/    ; ignored (comments)
   header_line ::= "FISh0002:" length ":" checksum ":" encoding ":"
                   ignored "\n"
   length ::= /[0-9]+/          ; number of bytes in content
   checksum ::= /[0-9A-Fa-f]{32}/ ; md5 of content, in hexadecimal
   encoding ::= /[ -9;-~]*/     ; name of content encoding
   ignored ::= /[ -~]*/         ; reserved
   weird_line ::= [ENCODING_charset] ; used to trace file corruption
 *)
let format_version = 2
let header = "FISh0002" let header_length = String.length header
let concat_list l =
  let length = List.fold_left (fun n s -> n + String.length s) 0 l in
  let buf = String.create length in
  ignore (List.fold_left
            (fun n s -> let k = String.length s in String.blit s 0 buf n k; n + k)
            0 l);
  buf

let build_header length sum =
  concat_list [header; ":";
               string_of_int length; ":";
               sum; ":";
               "\n"]

let parse_header line =
  let s = string_fields_stream ':' line in
  try
    let head = Stream.next s in
    let length_text = Stream.next s in
    let sum_text = Stream.next s in
    let encoding = stream_weak_next "" s in
    if (String.length head = 8 &&
        head.[0] == 'F' && head.[1] == 'I' &&
        head.[2] == 'S' && head.[3] == 'h')
    then
      let pack_format_version =
        try int_of_string (String.sub head 4 4) with _ ->
          raise (Invalid_format "bad header")
      in
      if pack_format_version < format_version
      then raise (Invalid_format (Printf.sprintf "dump file format version %d is no longer supported" pack_format_version))
      else if pack_format_version > format_version
      then raise (Invalid_format (Printf.sprintf "dump file format version %d is too recent (I only know %d)" pack_format_version format_version))
      else ((* ok *))
    else raise (Invalid_format "bad header");
    let length =
      try int_of_string length_text
      with _ -> raise (Invalid_format "length must be a positive decimal integer")
    in
    if length <= 0 then
      raise (Invalid_format "length must be a positive decimal integer");
    if String.length sum_text != 32 then
      raise (Invalid_format "md5sum must have 32 digits");
    let raw_sum =
      try string_of_hex sum_text
      with _ -> raise (Invalid_format "checksum is not an hexadecimal integer")
    in
    let unmarshal buf = Marshal.from_string buf 0
    in
    let _, decode =
      try Encodings.find encoding encodings
      with Not_found ->
        raise (Invalid_format ("encoding not supported: " ^ encoding))
    in
    unmarshal, length, raw_sum, decode
  with Stream.Failure ->
    raise (Invalid_format "not enough fields in header line")




(*** Dumping *)

let dump_stamp_lines tail =
  List.fold_left
    (fun t (name, content) ->
      if content = "??" then t
      else Printf.sprintf "#:%s: %s\n" name content :: t)
    tail ["Date", Config.now ();
          "Author", Config.who ();
          "Machine", Config.hostname ()]
  
let with_open_close open_f open_arg (close : 'a -> unit) f =
  let chan = open_f open_arg in
  let res =
    try f chan with e -> close chan; raise e
  in
  close chan; res
let with_open_in op name = with_open_close op name close_in
let with_open_out op name = with_open_close op name close_out




(*** Thawing *)


let thaw chan =
  try
    let line = input_significant_line chan in
    let unmarshal, length, sum, decode = parse_header line in
    let buf = String.create length in
    really_input chan buf 0 length;
    if not (Digest.string buf = sum) then raise Checksum_mismatch;
    (unmarshal (decode buf) : pack)
  with End_of_file -> raise Premature_end_of_file


let thaw_file filename =

  let m = !declaration_counter in 

  if m != 0 
  then Printf.printf "Warning! 
           Internal variable counters may not be accurate in thawed functions!
  variable counter value is %d\n" m;

  let pack = with_open_in open_in_bin filename thaw in
  globalTyEnv := TyMap.fold TyMap.add pack.functors !globalTyEnv;


(* delete ?? 
let freshen_env (n,(ts, ps)) = 
  incr declaration_counter;
  let ts1 = closTy idSub TMap.empty (inst_tyscheme idSub ts) in 
  (m+n,(ts1,ps)) (* should ps be freshened? *) 
*)

let freshen_env (n,v) = 
  incr declaration_counter;
  (m+n,v) (* should ps be freshened? *) 
in 
let add_list_to_env key xs env = 
  let xs2 = List.map freshen_env xs in 
(*  let xs3 = 
    try xs2 @ (TMap.find key env)
    with Not_found -> xs2 in 
 TMap.add key xs3 env *)
  TMap.add key xs2 env
in 
  globalVEnv := TMap.fold add_list_to_env pack.terms !globalVEnv


let load_dump base_name full_name = thaw_file full_name; provide base_name





(* End of file dump.ml. *)

